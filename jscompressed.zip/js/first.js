console.log("hai")
name='sachin'
console.log("My name is "+name)
console.log(typeof(name))