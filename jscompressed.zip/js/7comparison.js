let age=18
// console.log(age==18)
// console.log(age=='18')
// console.log(age>=18)
console.log(age<=18)
console.log(age===18)
console.log(age==='18')
console.log(age>18)
console.log(age<18)

