let numbers=[1,2,3,4,5,6]
let sum=0
for(i in numbers)
{
    sum=sum+numbers[i]
}
console.log(sum)
for(i in numbers)
{
    console.log(i+":"+numbers[i])
}