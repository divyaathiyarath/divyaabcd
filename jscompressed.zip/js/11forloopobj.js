let student={
    name:'amal',
    age:18
}
for(x in student)
{
    console.log(x,student[x])
}