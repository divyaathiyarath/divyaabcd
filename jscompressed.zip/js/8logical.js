// let instock=true
// let goodoffer=false
// let purchase=instock && goodoffer
// console.log(purchase)
// // OR
// let instock=true
// let goodoffer=false
// let purchase=instock || goodoffer
// console.log(purchase)
// // NOT
let instock=true
let purchase = !instock;
console.log(purchase)