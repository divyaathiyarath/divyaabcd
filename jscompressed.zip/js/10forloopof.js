let names=['a',2,3,4]
for(i of names)
{
    console.log(i)
}