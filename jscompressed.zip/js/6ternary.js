let cgpa=8
let result=cgpa>7?'Eligible':'Not eligible'
console.log(result)