function welcome(name)
{
    console.log("Welcome "+name)
}
welcome('Arun')


