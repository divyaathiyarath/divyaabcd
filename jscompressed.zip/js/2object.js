let student={
    name:'amal',
    age:18,
    isEligible:true

}
console.log(student.name)
console.log(student.isEligible)
console.log(student)