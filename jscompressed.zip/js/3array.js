let season=['winter','summer','Autumn','spring']
console.log(season)
season[4]='summer'
season[2]='Monsoon'
console.log(season)
console.log(season[0])