let a=5
let b='5'
console.log(a==b)
console.log(a===b)